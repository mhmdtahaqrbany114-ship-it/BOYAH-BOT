import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    ContextTypes
)
from flask import Flask, request

TOKEN = "8363224853:AAFTo0c0l8xTsHo7J2RCnktCuD9xc8JHtrc"
WEBHOOK_URL = "https://boyah-bot.onrender.com"

# ----------------- Flask Server -----------------
app = Flask(__name__)

# ----------------- Telegram Bot -----------------
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

LANG_KEYBOARD = InlineKeyboardMarkup([
    [InlineKeyboardButton("🇮🇷 Persian", callback_data="lang_fa"),
     InlineKeyboardButton("🇬🇧 English", callback_data="lang_en")]
])

FA_MENU = InlineKeyboardMarkup([
    [InlineKeyboardButton("👥 گروه BOYAH", callback_data="fa_group")],
    [InlineKeyboardButton("📢 کانال BOYAH", callback_data="fa_channel")],
    [InlineKeyboardButton("💬 پشتیبانی BOYAH", callback_data="fa_support")],
    [InlineKeyboardButton("🧑‍💻 آیدی AR", callback_data="fa_ar")],
    [InlineKeyboardButton("👑 آیدی ادمین", callback_data="fa_admin")],
    [InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="back_lang")]
])

EN_MENU = InlineKeyboardMarkup([
    [InlineKeyboardButton("👥 BOYAH Group", callback_data="en_group")],
    [InlineKeyboardButton("📢 BOYAH Channel", callback_data="en_channel")],
    [InlineKeyboardButton("💬 BOYAH Support", callback_data="en_support")],
    [InlineKeyboardButton("🧑‍💻 AR ID", callback_data="en_ar")],
    [InlineKeyboardButton("👑 Admin ID", callback_data="en_admin")],
    [InlineKeyboardButton("🔙 Back ↩️", callback_data="back_lang")]
])


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Hello 🌹\nWelcome to BOYAH BOT, please choose your language 🌹",
        reply_markup=LANG_KEYBOARD
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    data = query.data

    # ---------------- Language selection ----------------
    if data == "lang_fa":
        context.user_data["lang"] = "fa"
        await query.edit_message_text(
            "زبان شما تأیید شد 🇮🇷\nلطفاً یکی از گزینه‌های زیر را انتخاب کنید 👇",
            reply_markup=FA_MENU
        )

    elif data == "lang_en":
        context.user_data["lang"] = "en"
        await query.edit_message_text(
            "Your language has been confirmed 🇬🇧\nPlease choose one of the options below 👇",
            reply_markup=EN_MENU
        )

    # ---------------- Persian Menu ----------------
    elif data == "fa_group":
        await query.edit_message_text(
            "👥 گروه BOYAH\nبرای ورود به گروه کلیک کنید 👇\n🔗 https://t.me/BOYAH_GROUP",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="fa_menu")]])
        )

    elif data == "fa_channel":
        await query.edit_message_text(
            "📢 کانال BOYAH\nبرای مشاهده کانال کلیک کنید 👇\n🔗 https://t.me/BOYAH_CANELL",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="fa_menu")]])
        )

    elif data == "fa_support":
        await query.edit_message_text(
            "💬 پشتیبانی BOYAH\nبرای ارتباط با پشتیبانی کلیک کنید 👇\n🔗 https://t.me/+315jISnDjCM3ODdk",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="fa_menu")]])
        )

    elif data == "fa_ar":
        await query.edit_message_text(
            "🧑‍💻 آیدی AR\nبرای مشاهده آیدی کلیک کنید 👇\n🔗 https://t.me/AR_BOYAH",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="fa_menu")]])
        )

    elif data == "fa_admin":
        await query.edit_message_text(
            "👑 آیدی ادمین\nبرای ارتباط با ادمین کلیک کنید 👇\n🔗 https://t.me/AD_BOYAH",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت ↩️", callback_data="fa_menu")]])
        )

    elif data == "fa_menu":
        await query.edit_message_text(
            "منوی اصلی 👇",
            reply_markup=FA_MENU
        )

    # ---------------- English Menu ----------------
    elif data == "en_group":
        await query.edit_message_text(
            "👥 BOYAH Group\nClick below to join the group 👇\n🔗 https://t.me/BOYAH_GROUP",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back ↩️", callback_data="en_menu")]])
        )

    elif data == "en_channel":
        await query.edit_message_text(
            "📢 BOYAH Channel\nClick below to open the channel 👇\n🔗 https://t.me/BOYAH_CANELL",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back ↩️", callback_data="en_menu")]])
        )

    elif data == "en_support":
        await query.edit_message_text(
            "💬 BOYAH Support\nClick below to contact support 👇\n🔗 https://t.me/+315jISnDjCM3ODdk",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back ↩️", callback_data="en_menu")]])
        )

    elif data == "en_ar":
        await query.edit_message_text(
            "🧑‍💻 AR ID\nClick below to view the AR ID 👇\n🔗 https://t.me/AR_BOYAH",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back ↩️", callback_data="en_menu")]])
        )

    elif data == "en_admin":
        await query.edit_message_text(
            "👑 Admin ID\nClick below to contact the admin 👇\n🔗 https://t.me/AD_BOYAH",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back ↩️", callback_data="en_menu")]])
        )

    elif data == "en_menu":
        await query.edit_message_text(
            "Main menu 👇",
            reply_markup=EN_MENU
        )

    elif data == "back_lang":
        await query.edit_message_text(
            "Hello 🌹\nWelcome to BOYAH BOT, please choose your language 🌹",
            reply_markup=LANG_KEYBOARD
        )


async def set_webhook():
    app_telegram = Application.builder().token(TOKEN).build()
    await app_telegram.bot.set_webhook(f"{WEBHOOK_URL}/{TOKEN}")
    app_telegram.add_handler(CommandHandler("start", start))
    app_telegram.add_handler(CallbackQueryHandler(button_handler))
    await app_telegram.initialize()
    return app_telegram


@app.route(f"/{TOKEN}", methods=["POST"])
def webhook():
    update = Update.de_json(request.get_json(force=True), app_telegram.bot)
    app_telegram.create_task(app_telegram.process_update(update))
    return "OK", 200


@app.route("/")
def index():
    return "BOYAH BOT is Running ✅"


import asyncio
app_telegram = asyncio.run(set_webhook())

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)